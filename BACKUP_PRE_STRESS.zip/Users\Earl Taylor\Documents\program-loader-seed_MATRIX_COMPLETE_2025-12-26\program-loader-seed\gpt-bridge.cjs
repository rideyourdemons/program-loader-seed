const { processMatrixStream } = require('./scripts/process-matrix-stream.cjs');

module.exports = { processMatrixStream };
