/**
 * RYD Tools Page Renderer - HARDENED VERSION
 * Populates the tools grid once matrix data is ready.
 * 
 * PRODUCTION HARDENING:
 * - Error boundaries for all dynamic content
 * - Validation for all API data
 * - Loading and error states
 * - Edge case handling
 * - Memoization for performance
 */

(function() {
  'use strict';

  // Check utilities
  const { ErrorBoundary, withErrorBoundary } = window.RYD_ErrorBoundary || {
    ErrorBoundary: class { catch() {} },
    withErrorBoundary: (container, fn) => fn
  };
  const { schemas, validateData } = window.RYD_Validation || {
    schemas: {},
    validateData: (data) => ({ success: true, data })
  };
  const { renderCache } = window.RYD_Cache || { renderCache: { get: () => null, set: () => {} } };
  const { cleanData, cleanDataArray, ensureWhereItCameFrom } = window.RYD_DataSanitizer || {
    cleanData: (data) => data,
    cleanDataArray: (arr) => arr,
    ensureWhereItCameFrom: (data) => data
  };
  const { logError } = window.RYD_ErrorMonitor || { logError: () => {} };
  const { setMinHeight } = window.RYD_UIStability || { setMinHeight: () => {} };
  
  /**
   * CIRCULAR REFERENCE DETECTION - Prevents memory leaks
   * Non-blocking validation using WeakSet for O(1) lookups
   */
  const circularReferenceDetector = (function() {
    const visited = new WeakSet();
    const MAX_DEPTH = 10;
    
    function detectCircular(obj, path = [], depth = 0) {
      if (depth > MAX_DEPTH) {
        return { circular: true, path: path.join(' -> ') };
      }
      
      if (typeof obj !== 'object' || obj === null) {
        return { circular: false };
      }
      
      if (visited.has(obj)) {
        return { circular: true, path: path.join(' -> ') };
      }
      
      visited.add(obj);
      
      try {
        for (const key in obj) {
          if (obj.hasOwnProperty(key)) {
            const value = obj[key];
            if (typeof value === 'object' && value !== null) {
              const result = detectCircular(value, [...path, key], depth + 1);
              if (result.circular) {
                return result;
              }
            }
          }
        }
      } finally {
        // Clean up visited set periodically to prevent memory growth
        if (depth === 0 && visited.size > 1000) {
          visited.clear();
        }
      }
      
      return { circular: false };
    }
    
    return {
      detect: detectCircular,
      clear: () => visited.clear()
    };
  })();
  
  /**
   * NON-BLOCKING VALIDATION - Uses requestIdleCallback or setTimeout
   */
  function validateNonBlocking(data, validator, callback) {
    const validateFn = () => {
      try {
        const result = validator(data);
        callback(result);
      } catch (error) {
        callback({ success: false, error: error.message });
      }
    };
    
    // Use requestIdleCallback if available (non-blocking)
    if (window.requestIdleCallback) {
      requestIdleCallback(validateFn, { timeout: 100 });
    } else {
      // Fallback to setTimeout with minimal delay
      setTimeout(validateFn, 0);
    }
  }

  /**
   * Safe string truncation
   */
  function truncateString(str, maxLength = 100) {
    if (!str || typeof str !== 'string') return '';
    if (str.length <= maxLength) return str;
    return str.substring(0, maxLength - 3) + '...';
  }

  /**
   * Safe array access
   */
  function safeArray(arr, fallback = []) {
    if (!Array.isArray(arr)) return fallback;
    return arr;
  }

  /**
   * Sanitize description
   */
  function sanitizeDescription(raw, title) {
    if (window.RYD_UI && typeof window.RYD_UI.sanitizeDescription === 'function') {
      return window.RYD_UI.sanitizeDescription(raw, title);
    }
    return truncateString(String(raw || ''), 200);
  }

  /**
   * Render tools with error boundary protection
   */
  const renderTools = withErrorBoundary(null, function(tools) {
    const grid = document.getElementById('toolsGrid');
    if (!grid) {
      console.warn('[RYD Tools] Container #toolsGrid not found');
      return;
    }

    grid.innerHTML = '';

    // Validate and sanitize tools (non-blocking)
    let rawTools = tools || [];
    let validatedTools = [];
    
    // Quick synchronous validation first
    if (Array.isArray(rawTools)) {
      // Non-blocking circular reference check
      const circularCheck = circularReferenceDetector.detect({ tools: rawTools });
      if (circularCheck.circular) {
        console.warn('[RYD Tools] Circular reference detected in tools data:', circularCheck.path);
        rawTools = []; // Prevent memory leak
      }
      
      // Validate each tool asynchronously to prevent blocking
      validatedTools = rawTools.map((tool, index) => {
        // Quick synchronous validation
        if (!tool || typeof tool !== 'object') return null;
        
        // Check for circular references in tool
        const toolCircular = circularReferenceDetector.detect(tool);
        if (toolCircular.circular) {
          console.warn(`[RYD Tools] Circular reference in tool ${index}:`, toolCircular.path);
          return null;
        }
        
        // Full validation (can be async, but we do sync for now)
        const toolValidation = validateData(tool, schemas.tool, tool);
        const cleaned = cleanDataArray([toolValidation.data || tool], 'tool')[0];
        return cleaned ? ensureWhereItCameFrom(cleaned) : null;
      }).filter(Boolean);
    }

    if (validatedTools.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'card tool-card';
      empty.style.cssText = 'padding: 2rem; text-align: center; color: #666;';
      empty.textContent = 'No tools available yet.';
      grid.appendChild(empty);
      return;
    }

    validatedTools.forEach(tool => {
      if (!tool || typeof tool !== 'object') return;

      // Guardrail: Skip invalid cards (missing title and id)
      const toolTitle = tool.title || tool.name || tool.id;
      if (!toolTitle || String(toolTitle).trim() === '') {
        console.warn('[RYD Tools] Skipping tool with missing title/id:', tool);
        return;
      }

      try {
        const card = document.createElement('div');
        card.className = 'card tool-card';
        card.style.cssText = 'border: 1px solid #e0e0e0; border-radius: 8px; padding: 1.5rem; margin-bottom: 1rem; background: #fff; cursor: pointer; transition: transform 0.2s, box-shadow 0.2s;';
        
        // Make card hoverable
        card.addEventListener('mouseenter', () => {
          card.style.transform = 'translateY(-2px)';
          card.style.boxShadow = '0 4px 12px rgba(0,0,0,0.1)';
        });
        card.addEventListener('mouseleave', () => {
          card.style.transform = 'translateY(0)';
          card.style.boxShadow = 'none';
        });

        const title = document.createElement('h3');
        title.className = 'tool-title';
        title.textContent = truncateString(String(toolTitle), 60);
        title.style.cssText = 'margin: 0 0 0.5rem 0; font-size: 1.2em; color: #333;';
        card.appendChild(title);

        const desc = document.createElement('p');
        desc.className = 'tool-description';
        const cleaned = sanitizeDescription(tool.description || tool.summary || '', toolTitle);
        // Guardrail: Remove placeholder text
        const descText = cleaned && !cleaned.toLowerCase().includes('coming soon') && !cleaned.toLowerCase().includes('placeholder')
          ? cleaned
          : 'A practical tool for personal growth and well-being.';
        desc.textContent = descText;
        desc.style.cssText = 'margin: 0 0 1rem 0; color: #666; font-size: 0.9em; line-height: 1.5;';
        card.appendChild(desc);

        const meta = document.createElement('div');
        meta.className = 'tool-meta';
        meta.style.cssText = 'display: flex; gap: 1rem; margin-bottom: 1rem; font-size: 0.85em; color: #888;';

        if (tool.duration && String(tool.duration).trim()) {
          const duration = document.createElement('span');
          duration.className = 'tool-meta-item';
          duration.textContent = `⏱️ ${truncateString(String(tool.duration), 20)}`;
          meta.appendChild(duration);
        }

        if (tool.difficulty && String(tool.difficulty).trim()) {
          const difficulty = document.createElement('span');
          difficulty.className = 'tool-meta-item';
          difficulty.textContent = `📊 ${truncateString(String(tool.difficulty), 20)}`;
          meta.appendChild(difficulty);
        }

        if (meta.children.length > 0) {
          card.appendChild(meta);
        }

        const cta = document.createElement('a');
        const slug = encodeURIComponent(truncateString(String(tool.slug || tool.id || toolTitle || ''), 100));
        cta.href = `/tools/tool.html?slug=${slug}`;
        cta.textContent = 'Open Tool';
        cta.className = 'tool-cta';
        cta.style.cssText = 'display: inline-block; padding: 0.5rem 1rem; background: #667eea; color: white; text-decoration: none; border-radius: 4px; font-size: 0.9em;';
        cta.addEventListener('click', (e) => {
          e.preventDefault();
          window.location.href = cta.href;
        });
        card.appendChild(cta);

        // Make entire card clickable
        card.addEventListener('click', (e) => {
          // Don't trigger if clicking the CTA link or About button
          if (e.target === cta || cta.contains(e.target)) return;
          if (e.target.classList.contains('ryd-about-button') || e.target.closest('.ryd-about-button')) return;
          window.location.href = cta.href;
        });

        // Add "About This Tool" button
        if (window.RYD_ToolAbout && typeof window.RYD_ToolAbout.addAboutButton === 'function') {
          window.RYD_ToolAbout.addAboutButton(card, tool);
        }

        grid.appendChild(card);
      } catch (toolError) {
        console.error('[RYD Tools] Error rendering tool:', toolError);
        // Continue with next tool
      }
    });
  });

  /**
   * Render loading state with stability
   */
  function renderLoading() {
    const grid = document.getElementById('toolsGrid');
    if (!grid) return;
    
    // Set min-height to prevent layout shift
    setMinHeight(grid, '300px');
    
    grid.innerHTML = `
      <div class="ryd-loading" style="padding: 2rem; text-align: center; min-height: 300px; display: flex; flex-direction: column; align-items: center; justify-content: center;">
        <div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #667eea; border-radius: 50%; animation: spin 1s linear infinite;"></div>
        <p style="margin-top: 1rem; color: #666;">Loading tools...</p>
      </div>
      <style>
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      </style>
    `;
  }

  /**
   * Render error state
   */
  function renderError(error) {
    const grid = document.getElementById('toolsGrid');
    if (!grid) return;
    
    const boundary = new ErrorBoundary(grid);
    boundary.catch(error, { component: 'ryd-tools' });
  }

  /**
   * Handle ready event
   */
  function handleReady() {
    try {
      const tools = (window.RYD && typeof window.RYD.getTools === 'function')
        ? window.RYD.getTools()
        : [];
      
      renderTools(tools);
    } catch (error) {
      console.error('[RYD Tools] Error in handleReady:', error);
      renderError(error);
    }
  }

  /**
   * Initialize
   */
  function init() {
    const grid = document.getElementById('toolsGrid');
    if (!grid) {
      console.warn('[RYD Tools] Container #toolsGrid not found');
      return;
    }

    renderLoading();

    // Wait for utils if needed
    if (!window.RYD_ErrorBoundary) {
      window.addEventListener('ryd:utils-ready', () => {
        setTimeout(handleReady, 100);
      });
      return;
    }

    // Listen for ready event
    window.addEventListener('ryd:ready', handleReady);
    window.addEventListener('ryd:error', () => {
      renderTools([]);
    });

    // Try immediate render if data already available
    if (document.readyState !== 'loading') {
      setTimeout(handleReady, 100);
    }
  }

  // Initialize
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
