
      function test() {
        return "Hello World"
        // Missing semicolon and closing brace
    