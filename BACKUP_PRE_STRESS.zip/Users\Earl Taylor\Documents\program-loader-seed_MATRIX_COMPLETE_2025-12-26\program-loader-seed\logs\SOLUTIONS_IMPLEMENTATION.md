# Solutions Implementation Guide

This document provides specific, actionable solutions for all identified issues.

---

## Priority 1: Critical/High Priority Fixes

### Solution 1.1: Fix Logic Error in Website Monitor
**File:** `programs/website-monitor/index.js`  
**Line:** 199  
**Issue:** Redundant condition check

**Current Code:**
```javascript
const allChecksPassed = basicCheck.success && 
  (!expectedContent.length || (performanceCheck.success && performanceCheck.success));
```

**Fixed Code:**
```javascript
// Get content check result if it was performed
const contentCheckPassed = !expectedContent.length || 
  (basicCheck.success && basicCheck.statusCode === 200 ? 
    (() => {
      // Content check was performed, need to track it
      // This requires refactoring to store contentCheck result
      return true; // Placeholder - see full solution below
    })() : true);

const allChecksPassed = basicCheck.success && 
  (!expectedContent.length || contentCheckPassed) &&
  performanceCheck.success;
```

**Better Solution (Refactor):**
Store content check result and use it:
```javascript
// In performWebsiteCheck function, store contentCheck result
let contentCheckResult = { success: true };

// After content check:
if (basicCheck.success && basicCheck.statusCode === 200) {
  try {
    const response = await axios.get(websiteUrl, { timeout });
    const html = typeof response.data === "string" ? response.data : "";
    contentCheckResult = performContentCheck(html, expectedContent);
    // ... existing logging ...
  } catch (error) {
    contentCheckResult = { success: false, error: error.message };
    // ... existing logging ...
  }
}

// Then at summary:
const allChecksPassed = basicCheck.success && 
  (!expectedContent.length || contentCheckResult.success) &&
  performanceCheck.success;
```

---

### Solution 1.2: Add Interval Cleanup for Graceful Shutdown
**File:** `programs/website-monitor/index.js`  
**Issue:** Interval not cleared on unexpected exit

**Current Code:**
```javascript
const intervalId = setInterval(async () => {
  await performWebsiteCheck();
}, checkInterval);
```

**Fixed Code:**
```javascript
let intervalId = null;

// Store interval ID for cleanup
intervalId = setInterval(async () => {
  await performWebsiteCheck();
}, checkInterval);

// Enhanced cleanup function
function cleanup() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
    logger.info("Website monitor interval cleared");
  }
}

// Handle all exit scenarios
process.on("SIGINT", () => {
  logger.info("Website monitor shutting down...");
  cleanup();
  process.exit(0);
});

process.on("SIGTERM", () => {
  logger.info("Website monitor shutting down...");
  cleanup();
  process.exit(0);
});

// Handle uncaught errors
process.on("uncaughtException", (error) => {
  logger.error("Uncaught exception in website monitor:", error.message);
  cleanup();
  process.exit(1);
});

process.on("unhandledRejection", (reason) => {
  logger.error("Unhandled rejection in website monitor:", reason);
  cleanup();
  process.exit(1);
});
```

---

### Solution 1.3: Improve Program State Reporting
**File:** `programs/website-monitor/index.js`  
**Issue:** Program marked as "running" even when URL is missing

**Current Code:**
```javascript
export default async function run() {
  if (!websiteUrl) {
    logger.warn("Website monitor started but no URL configured...");
    return; // Exits but still marked as "running"
  }
  // ...
}
```

**Fixed Code:**
```javascript
import { setProgramRunning } from "../../core/state.js";

export default async function run() {
  if (!websiteUrl) {
    logger.warn("Website monitor started but no URL configured...");
    setProgramRunning("website-monitor", "warning"); // Use new state
    return;
  }
  
  setProgramRunning("website-monitor", "starting");
  // ... rest of code ...
  setProgramRunning("website-monitor", "running");
}
```

**Alternative:** Update state.js to support "warning" status, or handle in boot.js:
```javascript
// In scripts/boot.js, after program execution:
if (result instanceof Promise) {
  startPromises.push(
    result
      .then((returnValue) => {
        // Check if program returned early (undefined/null might indicate issue)
        if (returnValue === false || returnValue === "warning") {
          setProgramRunning(name, "warning");
        } else {
          setProgramRunning(name, "running");
        }
        logger.info(`Program ${name} started successfully`);
      })
      // ... rest
  );
}
```

---

## Priority 2: Medium Priority Enhancements

### Solution 2.1: Add Configuration Validation
**File:** `core/config-validator.js`  
**Issue:** No type validation for configuration values

**Add to validateAppConfig function:**
```javascript
export function validateAppConfig(config) {
  const required = ["appName", "environment"];
  const missing = required.filter(field => !config[field]);
  
  if (missing.length > 0) {
    throw new Error(`app.config.json missing required fields: ${missing.join(", ")}`);
  }
  
  const validEnvironments = ["local", "development", "staging", "production"];
  if (!validEnvironments.includes(config.environment)) {
    logger.warn(`Unknown environment: ${config.environment}. Valid: ${validEnvironments.join(", ")}`);
  }
  
  // NEW: Validate website configuration if present
  if (config.website) {
    if (config.website.url && typeof config.website.url !== "string") {
      throw new Error("website.url must be a string");
    }
    
    if (config.website.checkInterval !== undefined) {
      if (typeof config.website.checkInterval !== "number" || config.website.checkInterval < 1000) {
        throw new Error("website.checkInterval must be a number >= 1000 (milliseconds)");
      }
    }
    
    if (config.website.timeout !== undefined) {
      if (typeof config.website.timeout !== "number" || config.website.timeout < 100) {
        throw new Error("website.timeout must be a number >= 100 (milliseconds)");
      }
    }
    
    if (config.website.expectedStatus !== undefined) {
      if (typeof config.website.expectedStatus !== "number" || 
          config.website.expectedStatus < 100 || 
          config.website.expectedStatus > 599) {
        throw new Error("website.expectedStatus must be a valid HTTP status code (100-599)");
      }
    }
    
    if (config.website.expectedContent !== undefined) {
      if (!Array.isArray(config.website.expectedContent)) {
        throw new Error("website.expectedContent must be an array");
      }
    }
  }
  
  return true;
}
```

---

### Solution 2.2: Add Input Validation in Website Monitor
**File:** `programs/website-monitor/index.js`  
**Issue:** No validation for checkInterval values

**Current Code:**
```javascript
const checkInterval = appConfig.website?.checkInterval || 60000;
```

**Fixed Code:**
```javascript
let checkInterval = appConfig.website?.checkInterval || 60000;

// Validate and enforce minimum
if (typeof checkInterval !== "number" || checkInterval < 1000) {
  logger.warn(`Invalid checkInterval (${checkInterval}ms), using minimum of 1000ms`);
  checkInterval = 1000;
}

// Validate timeout
let timeout = appConfig.website?.timeout || 10000;
if (typeof timeout !== "number" || timeout < 100) {
  logger.warn(`Invalid timeout (${timeout}ms), using minimum of 100ms`);
  timeout = 100;
}

// Ensure timeout is less than checkInterval
if (timeout >= checkInterval) {
  logger.warn(`Timeout (${timeout}ms) should be less than checkInterval (${checkInterval}ms)`);
  timeout = Math.min(timeout, checkInterval - 1000);
}
```

---

### Solution 2.3: Enhance Error Logging with Context
**File:** `programs/website-monitor/index.js`  
**Issue:** Axios errors lack full context

**Enhanced Error Handling:**
```javascript
// In performBasicCheck function, enhance error logging:
catch (error) {
  const responseTime = Date.now() - startTime;
  
  // Log full error details in debug mode
  if (process.env.LOG_LEVEL === "DEBUG") {
    logger.debug("Full axios error:", {
      message: error.message,
      code: error.code,
      response: error.response ? {
        status: error.response.status,
        statusText: error.response.statusText,
        headers: error.response.headers,
        data: typeof error.response.data === "string" ? 
          error.response.data.substring(0, 200) : error.response.data
      } : null,
      request: error.request ? {
        method: error.config?.method,
        url: error.config?.url
      } : null
    });
  }
  
  // ... existing error categorization ...
}
```

---

## Priority 3: Code Quality Improvements

### Solution 3.1: Extract Shared Website Check Logic
**Files:** `programs/website-monitor/index.js`, `scripts/check-website.js`  
**Issue:** Code duplication

**Create:** `core/website-checker.js`
```javascript
import axios from "axios";

export async function performBasicCheck(url, timeout = 10000, expectedStatus = 200) {
  // Move performBasicCheck logic here
}

export function performContentCheck(html, expectedContent) {
  // Move performContentCheck logic here
}

export async function performPerformanceCheck(url, timeout = 10000) {
  // Move performPerformanceCheck logic here
}

export async function performWebsiteCheck(url, options = {}) {
  // Combine all checks into one function
  // Returns comprehensive result object
}
```

**Then update both files to import from this module.**

---

### Solution 3.2: Improve Logger Error Handling
**File:** `core/logger.js`  
**Issue:** Directory creation might fail silently

**Current Code:**
```javascript
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}
```

**Fixed Code:**
```javascript
let fileLoggingEnabled = true;

try {
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }
  
  // Test write access
  const testFile = path.join(logsDir, ".test-write");
  fs.writeFileSync(testFile, "test");
  fs.unlinkSync(testFile);
} catch (error) {
  fileLoggingEnabled = false;
  console.error(`[LOGGER] File logging disabled: ${error.message}`);
}

// Then in writeToFile:
function writeToFile(level, message, ...args) {
  if (!fileLoggingEnabled) return; // Skip if disabled
  
  try {
    const logMessage = formatLogMessage(level, message, ...args);
    fs.appendFileSync(logFile, logMessage, "utf8");
  } catch (error) {
    // Only log to console once if file logging fails
    if (fileLoggingEnabled) {
      console.error(`[LOGGER ERROR] Failed to write to log file:`, error.message);
      fileLoggingEnabled = false; // Disable to prevent spam
    }
  }
}
```

---

## Implementation Checklist

- [ ] **Priority 1.1:** Fix logic error in website-monitor (line 199)
- [ ] **Priority 1.2:** Add interval cleanup for graceful shutdown
- [ ] **Priority 1.3:** Improve program state reporting for missing URL
- [ ] **Priority 2.1:** Add configuration type validation
- [ ] **Priority 2.2:** Add input validation for checkInterval/timeout
- [ ] **Priority 2.3:** Enhance error logging with full context
- [ ] **Priority 3.1:** Extract shared website check logic (optional refactor)
- [ ] **Priority 3.2:** Improve logger error handling

---

## Testing After Implementation

After implementing fixes, run:
```bash
node scripts/analyze.js
```

This will verify:
- All fixes are working
- No new errors introduced
- Application still boots successfully
- All programs load correctly

---

## Notes

- All solutions maintain backward compatibility
- Solutions are incremental - can be implemented one at a time
- Test each fix individually before moving to the next
- Priority 3 items are optional improvements for code quality

