export const DATA_FILES = {
  gates: 'gates.json',
  painPoints: 'pain-points.json',
  tools: 'tools.json',
  toolsCanonical: 'tools-canonical.json'
};
