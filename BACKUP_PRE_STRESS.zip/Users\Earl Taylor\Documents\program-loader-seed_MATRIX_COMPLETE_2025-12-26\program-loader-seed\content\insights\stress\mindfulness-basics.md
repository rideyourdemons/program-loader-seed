# Mindfulness Basics

Mindfulness is the practice of paying attention to the present moment without judgment.