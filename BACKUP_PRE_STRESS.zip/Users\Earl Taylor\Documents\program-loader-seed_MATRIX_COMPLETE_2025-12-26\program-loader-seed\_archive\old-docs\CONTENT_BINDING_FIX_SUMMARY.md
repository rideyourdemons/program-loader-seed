Archived content removed during matrix expander migration.
